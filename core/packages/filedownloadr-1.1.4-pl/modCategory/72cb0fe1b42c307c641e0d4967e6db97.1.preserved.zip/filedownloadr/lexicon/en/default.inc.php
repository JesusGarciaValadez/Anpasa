<?php

/**
 * Default English lexicon topic
 *
 * @language en
 * @package filedownload
 * @subpackage lexicon
 */
$_lang['fd.err_save_counter'] = 'Could not save the download counting.';
$_lang['fd.breadcrumb.home'] = 'back';