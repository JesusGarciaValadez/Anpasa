<?php
$output = '
<label for="securitypatch20130604-activatePlugin">Activate securitypatch20130604 Plugin:</label>
<input type="checkbox" name="activatePlugin" id="securitypatch20130604-activatePlugin" value="1" checked="checked" />
';

return $output;
