<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'setup-options' => 'securitypatch20130604-1.0.0-pl/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => 'ec4e33423a00e306deff1796aae4af6d',
      'native_key' => NULL,
      'filename' => 'modPlugin/b6ec7336877480ce4d7938a1951f88c6.vehicle',
    ),
  ),
);