tinyMCE.addI18n('gu.modxlink',{
    link_desc:"Insert/edit link"
});