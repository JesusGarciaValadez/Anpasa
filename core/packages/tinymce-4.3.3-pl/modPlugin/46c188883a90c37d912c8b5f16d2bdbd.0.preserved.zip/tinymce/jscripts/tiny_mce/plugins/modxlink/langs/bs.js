tinyMCE.addI18n('bs.modxlink',{
    link_desc:"Insert/edit link"
});