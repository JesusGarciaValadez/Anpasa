tinyMCE.addI18n('no.modxlink',{
    link_desc:"Insert/edit link"
});