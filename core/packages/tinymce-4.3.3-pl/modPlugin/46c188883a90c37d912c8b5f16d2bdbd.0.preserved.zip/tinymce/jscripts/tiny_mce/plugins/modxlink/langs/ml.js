tinyMCE.addI18n('ml.modxlink',{
    link_desc:"Insert/edit link"
});