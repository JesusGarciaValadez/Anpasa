tinyMCE.addI18n('sr.modxlink',{
    link_desc:"Insert/edit link"
});