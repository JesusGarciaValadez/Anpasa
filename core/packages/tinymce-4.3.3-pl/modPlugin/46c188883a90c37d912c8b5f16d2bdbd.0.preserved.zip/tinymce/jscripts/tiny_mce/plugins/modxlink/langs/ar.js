tinyMCE.addI18n('ar.modxlink',{
    link_desc:"Insert/edit link"
});