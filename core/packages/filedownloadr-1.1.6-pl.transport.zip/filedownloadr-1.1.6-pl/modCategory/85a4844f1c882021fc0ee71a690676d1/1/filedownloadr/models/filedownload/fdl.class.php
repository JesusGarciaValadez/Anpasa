<?php
class FDL extends xPDOSimpleObject {}