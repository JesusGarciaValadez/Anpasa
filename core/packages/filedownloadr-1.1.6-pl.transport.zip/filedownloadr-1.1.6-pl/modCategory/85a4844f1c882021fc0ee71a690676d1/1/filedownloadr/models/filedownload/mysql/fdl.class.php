<?php
require_once (dirname(dirname(__FILE__)) . '/fdl.class.php');
class FDL_mysql extends FDL {}