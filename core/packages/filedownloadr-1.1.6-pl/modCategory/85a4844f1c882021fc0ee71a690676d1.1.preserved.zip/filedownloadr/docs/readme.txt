-------------------------------------------
Snippet: FileDownload (for MODX Revolution)
-------------------------------------------
Revo author: goldsky <goldsky@fastmail.fm>
The original Evo version author: Kyle Jaebker

A document download listing snippet for MODX Revolution

Official Documentation:
http://rtfm.modx.com/display/ADDON/FileDownload+R